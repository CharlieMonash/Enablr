export const REST_API_NAME = "backend-rest-api";
