package com.example.enablr_flutter_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
