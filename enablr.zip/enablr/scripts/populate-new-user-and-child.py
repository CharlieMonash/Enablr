from createTools import create_supporter

supporter = create_supporter({
    'email': '<your email here>',
    'first_name': 'Ron',
    'last_name': "Swanston"
})
